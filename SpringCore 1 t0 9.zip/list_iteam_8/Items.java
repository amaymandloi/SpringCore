package com.yash.list_iteam_8;

import java.util.ArrayList;
import java.util.List;

public class Items {

	List<Item> items = new ArrayList<Item>();

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

}
