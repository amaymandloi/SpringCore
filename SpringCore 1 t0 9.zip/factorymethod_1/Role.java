package com.yash.factorymethod_1;

public interface Role {
	void role();

}
