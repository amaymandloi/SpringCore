package com.yash.factorymethod_1;

public class DeveloperRole implements Role{
	
	public DeveloperRole()
	{
		System.out.println("DeveloperRole class Object create");
	}

	public void role() {
		System.out.println("Developer Develops the login in various Programming Language");
		
	}

}
