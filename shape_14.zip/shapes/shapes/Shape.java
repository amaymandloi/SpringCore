package com.yash.shapes;

public interface Shape {
	
	double areaOfShape();
	double sidesOfShape();

}
